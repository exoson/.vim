import sys


def main():
    print('TEST SUCEEDED!')
    sys.exit()


main()  # call_main_line
