
a = 1
b = 2
c = 3


def foo():
    a = 1
    b = 2
    c = 3


foo()
print('TEST SUCEEDED')
