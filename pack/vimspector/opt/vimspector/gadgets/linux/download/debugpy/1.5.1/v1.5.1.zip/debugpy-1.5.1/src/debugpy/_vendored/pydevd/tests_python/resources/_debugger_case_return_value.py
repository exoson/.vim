def method1():
    return 1


def method2():
    return 2


def main():
    method1()  # break here
    method2()
    print('TEST SUCEEDED!')


if __name__ == '__main__':
    main()
